package bank;

public final class  SavingsAccount extends account {

    private double interestRate;

    public SavingsAccount(int number, String holder, double balance, double interestRate) {
        super(number, holder, balance);
        this.interestRate = interestRate;
    }

    public void UpdateBalance(double interestRate) {
        balance *= interestRate;
    }

    public void withdraw(double amount) {
        balance -= amount;
    }
}
