/*
 EXERCÍCIO 01

A Classe SavingsAcount (Conta Poupança) deve possuir
um atributo chamado interestRate (juros de poupança)
que deve ser multiplicado pelo saldo toda vez que o
mesmo for atualizado pelo método updateBalance();

A Classe BusinessAcount deve possuir um atributo
chamado loanLimit (limite de empréstimo) que deve ser
analisado através de um condicional if toda vez que o
método loan (empréstimo) for chamado; Caso o
empréstimo seja maior que o limite, deve ser cobrada
uma taxa de 10.00 $ do Saldo;

No Programa Principal, Instancie as subclasses e
realize as seguintes operações: SavingsAccount
(ContaPoupança): Inicie o objeto com um valor de juros
da poupança (interestRate) no construtor da
Classe.
Realize uma atualização de Saldo, e depois um saque,
então exiba o Saldo atual. BusinessAcount(Conta
Empresarial): Inicie um limite de empréstimo
(loanLimit) no construtor da Classe, e
faça um
empréstimo.

Confira se os valores estão sendo calculados
corretamente.
 */
package bank;

public class Bank {

    public static void main(String[] args) {
        SavingsAccount acc = new SavingsAccount(1, "Bruno", 1000.00, 500.00);
        BusinessAccount bacc = new BusinessAccount(2, "Ryan", 100.00, 500.0);
        acc.UpdateBalance(2.0);
        System.out.println("New Balance Account: " + acc.balance);
        acc.withdraw(100.00);
        System.out.println("New Balance Account: " + acc.balance);

        bacc.loan(200);
        System.out.println("New Balance Business Account: " + bacc.balance);
    }

}
