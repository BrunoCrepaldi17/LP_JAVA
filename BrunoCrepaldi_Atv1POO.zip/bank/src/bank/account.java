package bank;

public class account {

    private int number;
    private String holder;
    Double balance;

    public account(int number, String holder, Double balance) {
        this.number = number;
        this.holder = holder;
        this.balance = balance;
    }
  
}
