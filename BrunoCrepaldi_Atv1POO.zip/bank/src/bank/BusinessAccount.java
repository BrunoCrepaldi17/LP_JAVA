package bank;

public final class BusinessAccount extends account {

    private double loanLimit;

    public BusinessAccount(int number, String holder, double balance, double loanLimit) {
        super(number, holder, balance);
        this.loanLimit = loanLimit;
    }

    public void loan(double amount) {
        if (amount <= loanLimit) {
            balance += amount - 10.0;
        }
        else {
            System.out.println("ERROR, LIMIT LESS THAN THE LOAN AMOUNT");
        }
    }
}
