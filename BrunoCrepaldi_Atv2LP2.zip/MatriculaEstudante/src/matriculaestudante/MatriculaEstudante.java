
package matriculaestudante;

public class MatriculaEstudante {

    public static void main(String[] args) {
        Estudante e = new Estudante("bruno",22,123,"ADS");
        System.out.println(e.exibirDados());
    }
    
}
