/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package empresa;

/**
 *
 * @author bcrep
 */
public class Desenvolvedor extends Funcionario {
    private String linguagem;

    public Desenvolvedor(String nome, double salario, int id, String linguagem) {
        super(nome, salario, id);
        this.linguagem = linguagem;
    }

    public double calcularSalarioAnual() {
        return getSalario() * 12 * 1.2; // aumento de 20%
    }

    public String getLinguagem() {
        return linguagem;
    }
}
