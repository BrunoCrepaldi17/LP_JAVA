
package gestao;


public class testeFuncionarios {

    public static void main(String[] args) {
        Gerente g1 = new Gerente("bruno", 22 , 2000.00, 5 , "adiministrativo");
        System.out.println(g1.imprimirInformacoes());
        System.out.println("Bonificação: "+g1.getBonificacao(g1.getSalario()));
        
        Vendedor v1 = new Vendedor("Ryan", 23 , 1000.00, 1 );
        System.out.println(v1.imprimirInformacoes());
        System.out.println("Bonificação: "+v1.getBonificacao(2, 150));
        
        Vendedor v2 = new Vendedor("Igor", 25 , 500.00, 2 );
        System.out.println(v1.imprimirInformacoes());
        System.out.println("Bonificação: "+v1.getBonificacao(2, 100));
        
        Vendedor v3 = new Vendedor("Nathan", 23 , 800.00, 3 );
        System.out.println(v1.imprimirInformacoes());
        System.out.println("Bonificação: "+v1.getBonificacao(5, 50));
       }    
    }
    

