
package gestao;

public final class Gerente extends Funcionario {
    private String setor;

    public Gerente(String nome, int idade, double salario, int numFuncionarios, String setor) {
        super(nome, idade, salario, numFuncionarios);
        this.setor = setor;
    }
    @Override
    public Double getBonificacao(double salario) {
       return salario *= 1.10;
    }
    public String imprimirInformacoes() {
        return "GERENTE{" 
                + "Nome= " + super.getNome()
                + " Idade= " + super.getIdade()
                + " Salário= " + super.getSalario()
                + " Numero de Funcionaros= " + super.getNumFuncionarios()
                + " Setor= " + setor +'}';
    }
}
