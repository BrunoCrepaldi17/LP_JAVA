/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestao;

/**
 *
 * @author bcrep
 */
public final class Vendedor extends Funcionario {
    private double valorVendas;
    private double comissao;

    public double getValorVendas() {
        return valorVendas;
    }

    public double getComissao() {
        return comissao;
    }
    
    public Vendedor(String nome, int idade, double salario, int numFuncionarios) {
        super(nome, idade, salario, numFuncionarios);
        this.valorVendas = valorVendas;
        this.comissao = comissao;
    }
    public Double getBonificacao(double valorVendas, double comissao) {
        return valorVendas *= comissao;
    }
    public String imprimirInformacoes() {
        return "VENDEDOR{" 
                + "Nome= " + super.getNome()
                + " Idade= " + super.getIdade()
                + " Salário= " + super.getSalario()
                + " Numero de Funcionaros= " + super.getNumFuncionarios()
                +'}';
    }
}
