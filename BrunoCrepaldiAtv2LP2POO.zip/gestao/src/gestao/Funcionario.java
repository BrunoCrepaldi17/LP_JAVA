/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestao;

/**
 *
 * @author bcrep
 */
public abstract class Funcionario {

    private String nome;
    private int idade;
    private double salario;
    private int numFuncionarios;

    public Funcionario(String nome, int idade, double salario, int numFuncionarios) {
        this.nome = nome;
        this.idade = idade;
        this.salario = salario;
        this.numFuncionarios = numFuncionarios;
    }

 public Double getBonificacao(double salario) {
        return null;
        
    }

    public String getNome() {
        return nome;
    }

    public int getIdade() {
        return idade;
    }

    public double getSalario() {
        return salario;
    }

    public int getNumFuncionarios() {
        return numFuncionarios;
    }
 
}
