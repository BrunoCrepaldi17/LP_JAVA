package hotel;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class Reservar {

    private final int numeroQuarto;
    private Date entrada;
    private Date saida;

    public Reservar(int numeroQuarto, Date entrada, Date saida) {
        if (saida.before(entrada)) {
            System.out.println("Erro na Reserva: A data de saída deve ser posterior à data de entrada.");
        }
        this.numeroQuarto = numeroQuarto;
        this.entrada = entrada;
        this.saida = saida;
    }

    public int getNumeroQuarto() {
        return numeroQuarto;
    }

    public Date getEntrada() {
        return entrada;
    }

    public Date getSaida() {
        return saida;
    }

    public long duracao() {
        long diferencaMilissegundos = saida.getTime() - entrada.getTime();
        return TimeUnit.DAYS.convert(diferencaMilissegundos, TimeUnit.MILLISECONDS);
    }

    public String ImpReserva() {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        return "Reserva: Quarto " + numeroQuarto
                + ", Entrada: " + sdf.format(entrada)
                + ", Saída: " + sdf.format(saida)
                + ", " + duracao() + " noites.";
    }

    public void atualizarDatas(Date entrada, Date novaEntrada, Date saida, Date novaSaida) {
        entrada = novaEntrada;
        saida = novaSaida;
        if (novaEntrada.before(entrada) || novaSaida.before(saida)) {
            System.out.println("Erro na atualização da Reserva: As datas de atualização devem ser futuras.");
        }else if (novaSaida.before(novaEntrada)) {
            System.out.println("Erro na atualização da Reserva: A data de saída deve ser posterior à data de entrada.");
        }
    }
    
      
}
