/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalho_string.atv6;

import java.util.Scanner;

/**
 *
 * @author bcrep
 */
public class atv6 {
    public static void main(String[] args) {
        Scanner leitura = new Scanner(System.in);
         System.out.println("Digite um nome: ");

                String nome000 = leitura.nextLine();
                String nome001[] = nome000.split(" ");
                String ultimoNome = nome001[nome001.length - 1].toUpperCase() + ",";
                String vbnm = "";
                System.out.println(ultimoNome);
                for (String vbnm0 : nome001) {
                    if (vbnm0.length() > 3) {
                        vbnm += vbnm0.substring(0, 1).toUpperCase();
                    }
                }

                for (int i = 0; i < vbnm.length() - 1; i++) {
                    ultimoNome += vbnm.charAt(i) + ".";

                }
                System.out.println(" A citação será: " + ultimoNome);
    }
}
