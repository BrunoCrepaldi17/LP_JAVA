/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalho_string.atv5;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author bcrep
 */
public class atv5 {
    public static void main(String[] args) {
        Scanner leitura = new Scanner(System.in);
        System.out.println("Digite o seu nome");
                String nome = leitura.nextLine();
                List<String> conectores = Arrays.asList("do", "da", "de", "e", "das", "dos", "di", "du");
                StringBuilder iniciais = new StringBuilder();
                for (String parte : nome.split(" ")) {
                    if (!conectores.contains(parte.toLowerCase())) {
                        iniciais.append(Character.toUpperCase(parte.charAt(0)));
                    }
                }
                System.out.println("Iniciais: " + iniciais.toString());
    }
}
