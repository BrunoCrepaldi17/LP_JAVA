/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalho_string.atv1;

import java.util.Scanner;

/**
 *
 * @author bcrep
 */
public class atv1 {
    public static void main(String[] args) {
        
    
    Scanner scanner = new Scanner(System.in);

System.out.println("Informe umas palavras: ");
String palavras = scanner.nextLine();

System.out.println("Quantidade de caracters: " + palavras.length());
System.out.println("Quantidade de palavras: " + palavras.split(" ").length);
  }
}