/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalho_string.atv9;

import java.util.Scanner;

/**
 *
 * @author bcrep
 */
public class atv9 {
    public static void main(String[] args) {
        Scanner leitura = new Scanner(System.in);
        System.out.println("Digite a data do seu nascimento. EX: dd/mm/aaaa");
                String data = leitura.nextLine();
                String mes = data.substring(3, 5);
                int mesA = Integer.valueOf(mes);
                if (mesA == 1) {
                    System.out.println("Voce nasceu no dia " + (data.substring(0, 2)) + " de janeiro de " + (data.substring(6, 10)));
                }
                if (mesA == 2) {
                    System.out.println("Voce nasceu no dia " + (data.substring(0, 2)) + " de fevereiro de " + (data.substring(6, 10)));
                }
                if (mesA == 3) {
                    System.out.println("Voce nasceu no dia " + (data.substring(0, 2)) + " de março de " + (data.substring(6, 10)));
                }
                if (mesA == 4) {
                    System.out.println("Voce nasceu no dia " + (data.substring(0, 2)) + " de abril de " + (data.substring(6, 10)));
                }
                if (mesA == 5) {
                    System.out.println("Voce nasceu no dia " + (data.substring(0, 2)) + " de maio de " + (data.substring(6, 10)));
                }
                if (mesA == 6) {
                    System.out.println("Voce nasceu no dia " + (data.substring(0, 2)) + " de junho de " + (data.substring(6, 10)));
                }
                if (mesA == 7) {
                    System.out.println("Voce nasceu no dia " + (data.substring(0, 2)) + " de julho de " + (data.substring(6, 10)));
                }
                if (mesA == 8) {
                    System.out.println("Voce nasceu no dia " + (data.substring(0, 2)) + " de agosto de " + (data.substring(6, 10)));
                }
                if (mesA == 9) {
                    System.out.println("Voce nasceu no dia " + (data.substring(0, 2)) + " de setembro de " + (data.substring(6, 10)));
                }
                if (mesA == 10) {
                    System.out.println("Voce nasceu no dia " + (data.substring(0, 2)) + " de outubro de " + (data.substring(6, 10)));
                }
                if (mesA == 11) {
                    System.out.println("Voce nasceu no dia " + (data.substring(0, 2)) + " de novembro de " + (data.substring(6, 10)));
                }
                if (mesA == 12) {
                    System.out.println("Voce nasceu no dia " + (data.substring(0, 2)) + " de dezembro de " + (data.substring(6, 10)));
                }
    }
}
