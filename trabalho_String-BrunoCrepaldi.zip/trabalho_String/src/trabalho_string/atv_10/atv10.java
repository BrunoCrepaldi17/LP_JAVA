/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalho_string.atv_10;

import java.util.Scanner;

/**
 *
 * @author bcrep
 */
public class atv10 {
    public static void main(String[] args) {
        Scanner leitura = new Scanner(System.in);
        String vetorLetras[] = {"A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"};
                System.out.println("DIgite o texto que vai ser codificado: ");
                String textoCod[] = leitura.nextLine().toUpperCase().split("");

                for (int i = 0; i < textoCod.length; i++) {
                    int j = 0;
                    while (j != 77) {
                        if (!textoCod[i].equals(" ") && textoCod[i].equals(vetorLetras[j])) {

                            if (j < 23) {
                                textoCod[i] = vetorLetras[j + 3];
                            } else {
                                textoCod[i] = vetorLetras[j - 3];
                            }
                            j = 77;
                        } else {

                            j++;
                        }
                    }

                }
                for (int d = 0; d < textoCod.length; d++) {
                    System.out.print(textoCod[d].toUpperCase());
                }
    }
}
