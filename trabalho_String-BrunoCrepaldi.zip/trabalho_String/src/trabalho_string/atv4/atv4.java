/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalho_string.atv4;

import java.util.Scanner;

/**
 *
 * @author bcrep
 */
public class atv4 {
    public static void main(String[] args) {
       Scanner scanner = new Scanner(System.in);
       
System.out.println("Informe alguns numeros: ");

String palavras = scanner.nextLine();

String novaPalavras = palavras.replace("1"," um," ).replace("2", " dois,").replace("3", " três,").replace("4", " quatro,").replace("5", " cinco,").replace("6", " seis,").replace("7", " sete,").replace("8", " oito,").replace("9", " nove,").replace("0", " zero,");
 
System.out.println(novaPalavras);
    }
}
