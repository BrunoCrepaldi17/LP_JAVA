/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalho_string.atv3;

import java.util.Scanner;

/**
 *
 * @author bcrep
 */
public class atv3 {
    public static void main(String[] args) {
     Scanner scanner = new Scanner(System.in);
        System.out.println("Informe um texto: ");
     String palavras = scanner.nextLine();   
        
System.out.println("Quantidade de caracters: " + palavras.length());
System.out.println(palavras.toUpperCase());

         int contarVogais = 0;
        
        palavras.toLowerCase();
        
        for (int i = 0; i < palavras.length(); i++){
            char c = palavras.charAt(i);
            if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u')
                contarVogais++;
        }
        
         String dig = palavras;
                dig = dig.replaceAll("\\D+", " ");
                System.out.println("A quantidade de digitos é: " + dig + " digitos");
        System.out.println("o numero de vogais é: "+ contarVogais);
        
    }
    
}
