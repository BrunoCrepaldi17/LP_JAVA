/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalho_string.atv8;

import java.util.Scanner;

/**
 *
 * @author bcrep
 */
public class atv8 {
    public static void main(String[] args) {
         Scanner leitura = new Scanner(System.in);
         System.out.println("Digite um nome e ele será exibido em forma de escada: ");
                String nomeE = leitura.nextLine();
                String letra = "";
                int i;
                for (i = 0; i <= nomeE.length() - 1; i++) {
                    letra += nomeE.charAt(i);
                    System.out.println(letra);
                }
    }
}
